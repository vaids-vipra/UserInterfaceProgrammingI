var PubDB = {
    "spirits": [{
        beverage_id: "572680",
        stock: 333
    },
    {
        beverage_id: "739874",
        stock: 1
    },{
        beverage_id: "571525",
        stock: 4
    },{
        beverage_id: "700152",
        stock: 9
    },{
        beverage_id: "859763",
        stock: 123
    },{
        beverage_id: "736568",
        stock: 18
    },{
        beverage_id: "240076",
        stock: 102
    },{
        beverage_id: "412153",
        stock: 32
    },{
        beverage_id: "777603",
        stock: 12
    },{
        beverage_id: "732312",
        stock: 3
    },{
        beverage_id: "605741",
        stock: 9
    },{
        beverage_id: "707855",
        stock: 12
    },{
        beverage_id: "857500",
        stock: 34
    },{
        beverage_id: "724332",
        stock: 18
    },{
        beverage_id: "861582",
        stock: 32
    },{
        beverage_id: "762761",
        stock: 19
    },{
        beverage_id: "753022",
        stock: 5
    },
]
}